<?php

// game routes
Route::name('games.baccarat.')
    ->namespace('Packages\Baccarat\Http\Controllers')
    ->middleware(['bindings', 'throttle:60,1', 'auth:api', 'active', '2fa'])
    ->group(function () {
        // games
        Route::post('api/games/baccarat/play', 'GameController@play')->name('play');
    });
