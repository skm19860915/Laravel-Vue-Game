<script>
import { mapState } from 'vuex'
import { Howl } from 'howler'

export default {
  data () {
    return {
      howl: {}
    }
  },

  computed: {
    ...mapState('settings', ['settings'])
  },

  methods: {
    sound (path) {
      if (this.settings.sounds) {
        if (!this.howl[path]) {
          this.howl[path] = new Howl({ src: [path] })
        }
        this.howl[path].play()
      }
    }
  }
}
</script>
