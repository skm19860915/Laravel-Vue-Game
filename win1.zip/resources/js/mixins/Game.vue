<script>
import { route } from '~/plugins/route'

export default {
  computed: {
    gamePackageId () {
      return this.$route.params.game
    },
    provablyFairGame () {
      return this.$store.getters['provably-fair/get'](this.gamePackageId) || {}
    }
  },

  methods: {
    getRoute (action) {
      return route(`games.${this.gamePackageId}.${action}`)
    }
  }
}
</script>
