<template>
  <div
    class="hand"
    :class="{ 'inactive': inactive }"
  >
    <div v-if="title" class="font-weight-thin title text-center mb-2">
      {{ title }}
    </div>
    <slot />
    <div class="playing-cards">
      <transition-group name="deal" tag="div" class="d-flex justify-center">
        <playing-card
          v-for="(card, i) in cards"
          :key="`card-${i}`"
          :card="card"
          :clickable="clickable"
          @click.native="click(i, card)"
        >
          <template v-slot:top>
            <slot v-if="$scopedSlots['top.' + i]" :name="`top.${i}`" />
          </template>
        </playing-card>
      </transition-group>
      <hand-score :score="score" />
      <hand-result
        :result="result"
        :class="resultClass"
      />
    </div>
    <hand-bet-win :bet="bet" :win="win" />
  </div>
</template>

<script>
import PlayingCard from './PlayingCard'
import HandScore from './HandScore'
import HandResult from './HandResult'
import HandBetWin from './HandBetWin'

export default {
  components: { PlayingCard, HandScore, HandResult, HandBetWin },
  props: {
    // array of cards, e.g. ['H2', 'H3']
    cards: {
      type: Array,
      required: true
    },
    score: {
      type: Number,
      required: false,
      default: -1
    },
    result: {
      type: String,
      required: false,
      default: ''
    },
    resultClass: {
      type: String,
      required: false,
      default: ''
    },
    bet: {
      type: Number,
      required: false,
      default: 0
    },
    win: {
      type: Number,
      required: false,
      default: 0
    },
    inactive: {
      type: Boolean,
      required: false,
      default: false
    },
    title: {
      type: String,
      required: false,
      default: ''
    },
    clickable: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  methods: {
    click (index, card) {
      this.$emit('playing-card-click', { index, card })
    }
  }
}
</script>

<style lang="scss" scoped>
.hand {
  min-height: 7em;
  transition: all 0.5s ease;

  &.inactive {
    opacity: 0.4;
   }

  .playing-cards {
    position: relative;
  }
}

.deal-enter-active {
  animation: deal 0.3s;
}

.deal-leave-active {
  animation: deal 0.3s reverse;
}

.deal-move {
  transition: transform 0.3s;
}

@keyframes deal {
  0% {
    transform: translateY(-100vh);
  }
  100% {
    transform: translateY(0);
  }
}
</style>
