<template>
  <transition name="chip">
    <div v-show="bet > 0" class="bet-win-container">
      <div class="bet-win my-2 ml-n5 ml-lg-0 text-center" :class="{ 'display-win': win > 0 }">
        <div class="front elevation-2">
          <v-chip small :input-value="true">
            {{ $t('Bet') }}
            {{ bet }}
          </v-chip>
        </div>
        <div class="back elevation-2">
          <v-chip small color="primary" :input-value="true">
            {{ $t('Win') }}
            {{ win }}
          </v-chip>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  props: {
    bet: {
      type: Number,
      required: true
    },
    win: {
      type: Number,
      required: true
    }
  }
}
</script>

<style lang="scss" scoped>
.chip-enter, .chip-leave-to {
  transform: translateY(100vh);
  opacity: 1;
}

.chip-enter-active, .chip-leave-active {
  transition: all 0.4s;
}

.bet-win-container {
  perspective: 300px;

  .bet-win {
    position: relative;
    transform-style: preserve-3d;
    transition: all 0.4s ease-out;

    .front, .back {
      position: absolute;
      width: 100%;
      height: 100%;
      backface-visibility: hidden;
      transition: all 2s;
    }

    .back {
      transform: rotateY(180deg);
    }

    &.display-win {
     transform: rotateY(180deg);
    }
  }
}
</style>
