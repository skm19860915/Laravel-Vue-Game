<template>
  <v-form ref="form" v-model="formIsValid" @submit.prevent="play">
    <div class="d-flex justify-center flex-wrap mt-3">
      <v-text-field
        v-model.number="bet"
        dense
        outlined
        :full-width="false"
        class="text-center flex-grow-0"
        :label="$t('Bet')"
        :disabled="playing"
        :rules="[validationInteger, v => validationMin(v, minBet), v => validationMax(v, Math.min(account.balance, maxBet))]"
        prepend-inner-icon="mdi-minus"
        append-icon="mdi-plus"
        @click:prepend-inner="decreaseBet"
        @click:append="increaseBet"
      >
        <template v-slot:prepend-inner>
          <v-btn small text icon color="primary" @click="bet = minBet">
            <v-icon small>mdi-arrow-down</v-icon>
          </v-btn>
          <v-btn small text icon color="primary" @click="decreaseBet">
            <v-icon small>mdi-minus</v-icon>
          </v-btn>
        </template>
        <template v-slot:append>
          <v-btn small text icon color="primary" @click="increaseBet">
            <v-icon small>mdi-plus</v-icon>
          </v-btn>
          <v-btn small text icon color="primary" @click="bet = maxBet">
            <v-icon small>mdi-arrow-up</v-icon>
          </v-btn>
        </template>
      </v-text-field>
      <v-btn
        type="submit"
        color="primary"
        :loading="loading"
        :disabled="disabled || !formIsValid || isPlayDisabled"
        class="ml-2"
      >
        {{ $t('Play') }}
      </v-btn>

      <v-btn class="mx-4" fab dark small color="primary" v-on:click="onClickHandler('sounds')">
        <template v-if="loader">
          <v-icon>mdi-volume-high</v-icon>
        </template>
        <template v-else>
          <v-icon>mdi-volume-off</v-icon>
        </template>
      </v-btn>
    </div>
  </v-form>
</template>

<script>
import { mapState } from 'vuex'
import { config } from '~/plugins/config'
import FormMixin from '~/mixins/Form'
import SoundMixin from '~/mixins/Sound'
import clickSound from '~/../audio/common/click.wav'

export default {
  mixins: [FormMixin, SoundMixin],

  props: {
    loading: {
      type: Boolean,
      required: true
    },
    playing: {
      type: Boolean,
      required: true
    },
    disabled: {
      type: Boolean,
      required: false,
      default: false
    }
  },

  data () {
    return {
      bet: null,
      loader: true
    }
  },

  computed: {
    ...mapState('auth', ['account']),
    gamePackageId () {
      return this.$route.params.game
    },
    provablyFairGame () {
      return this.$store.getters['provably-fair/get'](this.gamePackageId) || {}
    },
    defaultBet () {
      return parseInt(config(`${this.gamePackageId}.default_bet_amount`), 10)
    },
    minBet () {
      return parseInt(config(`${this.gamePackageId}.min_bet`), 10)
    },
    maxBet () {
      return parseInt(config(`${this.gamePackageId}.max_bet`), 10)
    },
    betStep () {
      return parseInt(config(`${this.gamePackageId}.bet_change_amount`), 10)
    },
    isPlayDisabled () {
      return !this.provablyFairGame.hash || this.playing || this.bet > this.account.balance
    }
  },

  created () {
    this.bet = this.defaultBet
  },

  methods: {
    play () {
      this.sound(clickSound)
      this.$emit('play', this.bet)
    },
    decreaseBet () {
      this.sound(clickSound)
      const bet = this.bet - this.betStep
      this.bet = Math.max(this.minBet, bet)
    },
    increaseBet () {
      this.sound(clickSound)
      const bet = this.bet + this.betStep
      this.bet = Math.min(this.maxBet, bet)
    },
    onClickHandler: function(key) {
      this.loader = !this.loader;
      if(!this.loader){
        this.$store.dispatch('settings/set', { key, value: null })
      }
      else{
        this.$store.dispatch('settings/set', { key, value: true })
      }
    }
  }
}
</script>
