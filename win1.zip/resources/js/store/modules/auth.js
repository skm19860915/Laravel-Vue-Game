import axios from 'axios'
import Cookies from 'js-cookie'
import {
  AUTH_CLEAR,
  AUTH_LOGOUT,
  AUTH_SAVE_TOKEN,
  AUTH_UPDATE_USER_ACCOUNT_BALANCE,
  AUTH_UPDATE_USER
} from '../mutation-types'

// state
export const state = {
  user: null,
  account: null,
  token: Cookies.get('token')
}

// getters
export const getters = {
  check: state => state.user !== null
}

// mutations
export const mutations = {
  [AUTH_SAVE_TOKEN] (state, { token, remember }) {
    state.token = token
    Cookies.set('token', token, { expires: remember ? 365 : null })
  },

  [AUTH_CLEAR] (state) {
    state.token = null
    Cookies.remove('token')
  },

  [AUTH_LOGOUT] (state) {
    state.user = null
    state.token = null

    Cookies.remove('token')
  },

  [AUTH_UPDATE_USER] (state, { user }) {
    state.user = user
    state.account = user.account
  },

  [AUTH_UPDATE_USER_ACCOUNT_BALANCE] (state, balance) {
    state.account.balance = balance
  }
}

// actions
export const actions = {
  saveToken ({ commit, dispatch }, payload) {
    commit(AUTH_SAVE_TOKEN, payload)
  },

  async fetchUser ({ commit }) {
    try {
      const { data } = await axios.get('/api/user')

      commit(AUTH_UPDATE_USER, { user: data })
    } catch (e) {
      commit(AUTH_CLEAR)
    }
  },

  updateUser ({ commit }, payload) {
    commit(AUTH_UPDATE_USER, payload)
  },

  updateUserAccountBalance ({ commit }, balance) {
    commit(AUTH_UPDATE_USER_ACCOUNT_BALANCE, balance)
  },

  async logout ({ commit }, server = true) {
    if (server) {
      try {
        await axios.post('/api/auth/logout')
      } catch (e) {
        //
      }
    }

    commit(AUTH_LOGOUT)
  },

  async fetchOAuthRedirectUrl (ctx, { provider }) {
    const { data } = await axios.post(`/api/oauth/${provider}/url`)

    return data.url
  }
}
