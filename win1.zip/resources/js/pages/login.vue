<template>
  <v-container class="fill-height" fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" sm="8" md="6" lg="4">
        <v-card class="elevation-12">
          <v-toolbar color="primary">
            <router-link :to="{ name: 'home' }">
              <v-avatar size="40" tile>
                <v-img :src="appLogoUrl" />
              </v-avatar>
            </router-link>
            <v-toolbar-title class="ml-2">
              {{ $t('Authentication') }}
            </v-toolbar-title>
          </v-toolbar>
          <v-card-text>
            <o-auth></o-auth>
            <v-form v-model="formIsValid" @submit.prevent="login">
              <!-- <v-text-field
                v-model="form.email"
                :label="$t('Email')"
                type="email"
                name="email"
                :rules="[validationRequired, validationEmail]"
                :error="form.errors.has('email')"
                :error-messages="form.errors.get('email')"
                outlined
                @keydown="clearFormErrors"
              /> -->

              <v-text-field
                v-model="form.identity"
                :label="$t('Name')"
                type="text"
                name="identity"
                :rules="[validationRequired]"
                :error="form.errors.has('identity')"
                :error-messages="form.errors.get('identity')"
                outlined
                @keydown="clearFormErrors($event,'identity')"
              />

              <v-text-field
                v-model="form.password"
                :label="$t('Password')"
                :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
                :type="showPassword ? 'text' : 'password'"
                name="password"
                :rules="[validationRequired]"
                :error="form.errors.has('password')"
                :error-messages="form.errors.get('password')"
                outlined
                counter
                @click:append="showPassword = !showPassword"
                @keydown="clearFormErrors"
              />

              <v-checkbox
                v-model="remember"
                name="remember"
                :label="$t('Remember me')"
                color="primary"
              />

              <v-row align="center">
                <v-col class="text-center text-md-left">
                  <v-btn type="submit" color="primary" :disabled="!formIsValid || form.busy" :loading="form.busy">
                    {{ $t('Log in') }}
                  </v-btn>
                </v-col>
                <v-col class="text-center text-md-right">
                  <router-link :to="{ name: 'password.email' }">
                    {{ $t('Forgot password?') }}
                  </router-link>
                </v-col>
              </v-row>
            </v-form>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import { config } from '~/plugins/config'
import Form from 'vform'
import FormMixin from '~/mixins/Form'
import OAuth from '~/components/OAuth'
import { mapState } from 'vuex'

export default {
  middleware: 'guest',

  mixins: [FormMixin],

  components: {
    OAuth
  },

  metaInfo () {
    return { title: this.$t('Authentication') }
  },

  data: () => ({
    showPassword: false,
    form: new Form({
      // email: '',
      identity: '',
      password: ''
    }),
    remember: false
  }),

  computed: {
    ...mapState('auth', [
      'user'
    ]),
    appLogoUrl () {
      return config('app.logo')
    }
  },

  methods: {
    async login () {
      // Submit the form.
      const { data } = await this.form.post('/api/auth/login')

      // Save the token.
      this.$store.dispatch('auth/saveToken', {
        token: data.token,
        remember: this.remember
      })

      // Fetch the user
      await this.$store.dispatch('auth/fetchUser')

      if (this.user.two_factor_auth_enabled && !this.user.two_factor_auth_passed) {
        this.$router.push({ name: '2fa' })
      } else {
        this.$router.push({ name: 'home' })
      }
    }
  }
}
</script>
