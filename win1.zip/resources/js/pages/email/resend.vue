<template>
  <v-container class="fill-height" fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" sm="8" md="6" lg="4">
        <v-card class="elevation-12">
          <v-toolbar color="primary">
            <router-link :to="{ name: 'home' }">
              <v-avatar size="40" tile>
                <v-img :src="appLogoUrl" />
              </v-avatar>
            </router-link>
             <v-toolbar-title class="ml-2">
              {{ $t('Email verification') }}
            </v-toolbar-title>
            <v-spacer/>
          </v-toolbar>
          <v-card-text>
            <v-form ref="form" v-model="formIsValid" @submit.prevent="send">
              <v-text-field
                v-model="form.email"
                :label="$t('Email')"
                type="email"
                name="email"
                :rules="[validationRequired, validationEmail]"
                :error="form.errors.has('email')"
                :error-messages="form.errors.get('email')"
                outlined
                @keydown="clearFormErrors"
              />

              <v-btn type="submit" color="primary" :disabled="!formIsValid || form.busy" :loading="form.busy">
                {{ $t('Resend verification link') }}
              </v-btn>
            </v-form>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import { config } from '~/plugins/config'
import Form from 'vform'
import FormMixin from '~/mixins/Form'

export default {
  middleware: 'guest',

  mixins: [FormMixin],

  metaInfo () {
    return { title: this.$t('Email verification') }
  },

  data: () => ({
    status: '',
    form: new Form({
      email: ''
    })
  }),

  computed: {
    appLogoUrl () {
      return config('app.logo')
    }
  },

  created () {
    if (this.$route.query.email) {
      this.form.email = this.$route.query.email
    }
  },

  methods: {
    async send () {
      const { data } = await this.form.post('/api/email/resend')

      this.$store.dispatch('message/success', { text: data.status })

      this.form.reset()
      this.$refs.form.reset()
    }
  }
}
</script>
