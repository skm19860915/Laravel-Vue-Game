<template />
<script>
import axios from 'axios'

const qs = (params) => Object.keys(params).map(key => `${key}=${params[key]}`).join('&')

export default {
  middleware: 'guest',

  metaInfo () {
    return { title: this.$t('Email verification') }
  },

  async beforeRouteEnter (to, from, next) {
    try {
      const { data } = await axios.post(`/api/email/verify/${to.params.id}?${qs(to.query)}`)

      // there is no access to this in beforeRouteEnter()
      next(vm => {
        vm.$store.dispatch('message/success', { text: data.status })
        vm.$router.push({ name: 'login' })
      })
    } catch (e) {
      next(vm => {
        vm.$store.dispatch('message/error', { text: e.response.data.status })
        vm.$router.push({ name: 'login' })
      })
    }
  },

  data: () => ({
    error: '',
    success: ''
  })
}
</script>
