<template>
  <div class="fill-height">
    <animated-background />
    <component :is="gameComponent" />
    <game-menu />
  </div>
</template>

<script>
import AnimatedBackground from '~/components/AnimatedBackground'
import GameMenu from '~/components/Games/GameMenu'

export default {
  middleware: ['auth', '2fa_passed', 'game'],

  components: { AnimatedBackground, GameMenu },

  metaInfo () {
    return { title: this.gameComponent ? this.$t(this.gameComponent.name) : '' }
  },

  data () {
    return {
      gameComponent: null
    }
  },

  created () {
    this.initGameComponent(this.$route.params.game)
  },

  methods: {
    async initGameComponent (gamePackageId) {
      // create provably fair game
      this.$store.dispatch('provably-fair/create', { key: gamePackageId })

      // dynamically load game component
      const module = await import(/* webpackChunkName: 'js/games/[request]' */`packages/${gamePackageId}/resources/js/game`)

      this.gameComponent = module.default
    }
  },

  async beforeRouteUpdate (to, from, next) {
    await this.initGameComponent(to.params.game)

    next()
  }
}
</script>
