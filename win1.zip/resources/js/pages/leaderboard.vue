<template>
  <v-container>
    <v-row align="center" justify="center">
      <v-col cols="12">
        <v-card>
          <v-toolbar>
            <v-toolbar-title>
              {{ $t('Leaderboard') }}
            </v-toolbar-title>
            <v-spacer></v-spacer>
          </v-toolbar>
          <v-card-text>
            <data-table
              api="/api/leaderboard"
              :headers="headers"
              :search-enabled="false"
              sort-by="bet_total"
            >
              <template v-slot:item.name="{ item }">
                <v-avatar size="25">
                  <v-img :src="item.avatar_url" />
                </v-avatar>
                <user-profile-modal :user="{ id: item.id, name: item.name }" />
              </template>
            </data-table>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import DataTable from '~/components/DataTable'
import UserProfileModal from '~/components/UserProfileModal'

export default {
  middleware: ['auth', '2fa_passed'],

  components: { DataTable, UserProfileModal },

  metaInfo () {
    return { title: this.$t('Leaderboard') }
  },

  computed: {
    headers () {
      return [
        { text: this.$t('Player'), value: 'name' },
        { text: this.$t('Bets'), value: 'bet_count', format: 'integer', align: 'right' },
        { text: this.$t('Wagered'), value: 'bet_total', format: 'decimal', align: 'right' },
        { text: this.$t('Profit'), value: 'profit_total', format: 'decimal', align: 'right' },
        { text: this.$t('Max profit'), value: 'profit_max', format: 'decimal', align: 'right' }
      ]
    }
  }
}
</script>
