<template>
  <div>
    <v-tabs centered>
      <template v-if="authenticated && user.is_admin">
        <v-tab v-for="(tab,i) in tabs" :to="{ name: tab.route }" :key="i">
          {{ tab.name }}
        </v-tab>
      </template>
    </v-tabs>
    <router-view />
  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'

export default {
  middleware: ['auth', '2fa_passed'],

  data () {
    return {
      activeTab: null
    }
  },

  computed: {
    tabs () {
      return [
        { route: 'history.user', name: this.$t('My') },
        { route: 'history.recent', name: this.$t('Recent') },
        { route: 'history.wins', name: this.$t('Wins') },
        { route: 'history.losses', name: this.$t('Losses') }
      ]
    },
    ...mapState('auth', ['user', 'account', 'token']),
    ...mapGetters({
      authenticated: 'auth/check',
    })
  }
}
</script>
