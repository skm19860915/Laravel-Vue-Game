<template>
  <v-container>
    <v-row>
      <v-col cols="12" lg="6">
        <v-card class="text-center" :loading="!data">
          <v-card-title class="headline font-weight-thin justify-center">
            {{ $t('User base last 7 days') }}
          </v-card-title>
          <v-card-text>
            <v-sheet color="rgba(0, 0, 0, .15)">
              <v-sparkline
                :value="data ? data.user_base_by_day : Array(7).fill(0)"
                :color="chartLineColor"
                height="150"
                padding="24"
                stroke-linecap="round"
                line-width="2"
                smooth="5"
              >
                <template v-slot:label="item">
                  {{ short(item.value) }}
                </template>
              </v-sparkline>
            </v-sheet>
          </v-card-text>
        </v-card>
      </v-col>
      <v-col cols="12" lg="6" class="text-center">
        <v-card  :loading="!data">
          <v-card-title class="headline font-weight-thin justify-center">
            {{ $t('Sign-ups') }}
          </v-card-title>
          <v-card-text>
            <v-row>
              <v-col cols="12" md="6">
                <v-progress-circular
                  :rotate="-90"
                  :size="200"
                  :width="30"
                  :value="data ? 100 * data.sign_ups_last_month / (data.sign_ups_last_month + data.sign_ups_this_month) : 0"
                  color="primary"
                >
                  <span class="headline">{{ data ? data.sign_ups_last_month : 0 }}</span>
                </v-progress-circular>
                <v-subheader class="title font-weight-thin justify-center mt-3">
                  {{ $t('last month') }}
                </v-subheader>
              </v-col>
              <v-col cols="12" md="6" class="text-center">
                <v-progress-circular
                  :rotate="-90"
                  :size="200"
                  :width="30"
                  :value="data ? 100 * data.sign_ups_this_month / (data.sign_ups_last_month + data.sign_ups_this_month) : 0"
                  color="primary"
                >
                  <span class="headline">{{ data ? data.sign_ups_this_month : 0 }}</span>
                </v-progress-circular>
                <v-subheader class="title font-weight-thin justify-center mt-3">
                  {{ $t('this month') }}
                </v-subheader>
              </v-col>
            </v-row>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" lg="12">
        <v-card class="text-center" :loading="!data">
          <v-card-title class="headline font-weight-thin justify-center">
            {{ $t('Sign-ups by method') }}
          </v-card-title>
          <v-card-text>
            <v-simple-table>
              <template v-slot:default>
                <thead>
                  <tr>
                    <th class="text-left">{{ $t('Source') }}</th>
                    <th class="text-right">{{ $t('Count') }}</th>
                  </tr>
                </thead>
                <tbody>
                  <template v-if="data">
                    <tr v-for="item in data.sign_ups_by_method" :key="item.source">
                      <td class="text-left">{{ ucfirst(item.source) }}</td>
                      <td class="text-right">{{ integer(item.count) }}</td>
                    </tr>
                  </template>
                  <template v-else>
                    <tr v-for="(v,i) in Array(3).fill(0)" :key="i">
                      <td colspan="2">
                        <v-skeleton-loader type="text" />
                      </td>
                    </tr>
                  </template>
                </tbody>
              </template>
            </v-simple-table>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from 'axios'
import { integer, short } from '~/plugins/format'
import { ucfirst } from '~/plugins/utils'

export default {
  middleware: ['auth', '2fa_passed', 'admin'],

  metaInfo () {
    return { title: this.$t('Dashboard') + ' ' + this.$t('Users') }
  },

  computed: {
    theme () {
      const mode = this.$vuetify.theme.isDark ? 'dark' : 'light'
      return this.$vuetify.theme.themes[mode]
    },
    chartLineColor () {
      return this.theme.primary
    }
  },

  data () {
    return {
      data: null
    }
  },

  async created () {
    const { data } = await axios.get('/api/admin/dashboard/users')

    this.data = data
  },

  methods: {
    integer,
    short,
    ucfirst
  }
}
</script>
