<template>
  <v-container>
    <v-row>
      <v-col cols="12" lg="6" class="text-center">
        <v-card :loading="!data">
          <v-card-title class="headline font-weight-thin justify-center">
            {{ $t('Bets') }}
          </v-card-title>
          <v-card-text>
            <v-row>
              <v-col cols="12" md="6">
                <v-progress-circular
                  :rotate="-90"
                  :size="200"
                  :width="30"
                  :value="data ? 100 * data.bets_last_month / (data.bets_last_month + data.bets_this_month) : 0"
                  color="primary"
                >
                  <span class="headline">{{ data ? data.bets_last_month : 0 }}</span>
                </v-progress-circular>
                <v-subheader class="title font-weight-thin justify-center mt-3">
                  {{ $t('last month') }}
                </v-subheader>
              </v-col>
              <v-col cols="12" md="6" class="text-center">
                <v-progress-circular
                  :rotate="-90"
                  :size="200"
                  :width="30"
                  :value="data ? 100 * data.bets_this_month / (data.bets_last_month + data.bets_this_month) : 0"
                  color="primary"
                >
                  <span class="headline">{{ data ? data.bets_this_month : 0 }}</span>
                </v-progress-circular>
                <v-subheader class="title font-weight-thin justify-center mt-3">
                  {{ $t('this month') }}
                </v-subheader>
              </v-col>
            </v-row>
          </v-card-text>
        </v-card>
      </v-col>
      <v-col cols="12" lg="6" class="text-center">
        <v-card :loading="!data">
          <v-card-title class="headline font-weight-thin justify-center">
            {{ $t('House edge') }}
          </v-card-title>
          <v-card-text>
            <v-row>
              <v-col cols="12" md="6">
                <v-progress-circular
                  :rotate="data ? data.house_edge_last_month > 0 ? -90 : -90-(360*Math.abs(data.house_edge_last_month)/100) : 0"
                  :size="200"
                  :width="30"
                  :value="data ? Math.abs(data.house_edge_last_month) : 0"
                  :color="!data || data.house_edge_last_month > 0 ? 'primary' : 'error'"
                >
                  <span class="headline">{{ percentage(data ? data.house_edge_last_month : 0) }}</span>
                </v-progress-circular>
                <v-subheader class="title font-weight-thin justify-center mt-3">
                  {{ $t('last month') }}
                </v-subheader>
              </v-col>
              <v-col cols="12" md="6">
                <v-progress-circular
                  :rotate="data ? data.house_edge_this_month > 0 ? -90 : -90-(360*Math.abs(data.house_edge_this_month)/100) : 0"
                  :size="200"
                  :width="30"
                  :value="data ? Math.abs(data.house_edge_this_month) : 0"
                  :color="!data || data.house_edge_this_month > 0 ? 'primary' : 'error'"
                >
                  <span class="headline">{{ percentage(data ? data.house_edge_this_month : 0) }}</span>
                </v-progress-circular>
                <v-subheader class="title font-weight-thin justify-center mt-3">
                  {{ $t('this month') }}
                </v-subheader>
              </v-col>
            </v-row>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" lg="12">
        <v-card class="text-center" :loading="!data">
          <v-card-title class="headline font-weight-thin justify-center">
            {{ $t('Wagered last 8 weeks') }}
          </v-card-title>
          <v-card-text>
            <v-sheet color="rgba(0, 0, 0, .15)">
              <v-sparkline
                :value="data ? data.wagered_by_week : Array(8).fill(0)"
                :color="chartLineColor"
                height="100"
                padding="24"
                stroke-linecap="round"
                line-width="2"
                smooth="5"
              >
                <template v-slot:label="item">
                  {{ short(item.value) }}
                </template>
              </v-sparkline>
            </v-sheet>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" lg="12">
        <v-card class="text-center" :loading="!data">
          <v-card-title class="headline font-weight-thin justify-center">
            {{ $t('Totals by game') }}
          </v-card-title>
          <v-card-text>
            <v-simple-table>
              <template v-slot:default>
                <thead>
                  <tr>
                    <th class="text-left">{{ $t('Game') }}</th>
                    <th class="text-right">{{ $t('Wagered') }}</th>
                    <th class="text-right">{{ $t('Won') }}</th>
                    <th class="text-right">{{ $t('Return to player') }}</th>
                    <th class="text-right">{{ $t('House profit') }}</th>
                    <th class="text-right">{{ $t('House edge') }}</th>
                  </tr>
                </thead>
                <tbody>
                  <template v-if="data">
                    <tr v-for="item in data.stats_by_game" :key="item.game">
                      <td class="text-left">{{ item.game }}</td>
                      <td class="text-right">{{ integer(item.bet_total) }}</td>
                      <td class="text-right">{{ integer(item.win_total) }}</td>
                      <td class="text-right">{{ percentage(100 - item.house_edge) }}</td>
                      <td class="text-right">{{ integer(item.bet_total-item.win_total) }}</td>
                      <td class="text-right">{{ percentage(item.house_edge) }}</td>
                    </tr>
                  </template>
                  <template v-else>
                    <tr v-for="(v,i) in Array(5).fill(0)" :key="i">
                      <td colspan="6">
                        <v-skeleton-loader type="text" />
                      </td>
                    </tr>
                  </template>
                </tbody>
              </template>
            </v-simple-table>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from 'axios'
import { integer, percentage, short } from '~/plugins/format'

export default {
  middleware: ['auth', '2fa_passed', 'admin'],

  metaInfo () {
    return { title: this.$t('Dashboard') + ' ' + this.$t('Games') }
  },

  computed: {
    theme () {
      const mode = this.$vuetify.theme.isDark ? 'dark' : 'light'
      return this.$vuetify.theme.themes[mode]
    },
    chartLineColor () {
      return this.theme.primary
    }
  },

  data () {
    return {
      data: null
    }
  },

  async created () {
    const { data } = await axios.get('/api/admin/dashboard/games')

    this.data = data
  },

  methods: {
    integer,
    percentage,
    short
  }
}
</script>
