<template>
  <v-container>
    <v-row align="center" justify="center">
      <v-col cols="12" md="6">
        <v-card>
          <v-toolbar>
            <v-btn @click="$router.go(-1)" icon>
              <v-icon>mdi-arrow-left</v-icon>
            </v-btn>
            <v-toolbar-title>
              {{ $t('User {0}', [this.id]) }}
            </v-toolbar-title>
            <v-spacer></v-spacer>
            <user-menu :id="id" />
          </v-toolbar>
          <v-card-text>
            <p>
              {{ $t('Are you sure you want to delete this user?') }}
            </p>
            <v-form @submit.prevent="destroy">
              <v-btn type="submit" color="error" :disabled="form.busy" :loading="form.busy">{{ $t('Delete') }}</v-btn>
            </v-form>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import Form from 'vform'
import UserMenu from '~/components/Admin/UserMenu'

export default {
  middleware: ['auth', '2fa_passed', 'admin'],

  components: { UserMenu },

  props: ['id'],

  metaInfo () {
    return { title: this.$t('User {0}', [this.id]) }
  },

  data () {
    return {
      form: new Form()
    }
  },

  methods: {
    async destroy () {
      const { data } = await this.form.delete(`/api/admin/users/${this.id}`)

      this.$store.dispatch('message/success', { text: data.status })

      this.$router.push({ name: 'admin.users.index' })
    }
  }
}
</script>
