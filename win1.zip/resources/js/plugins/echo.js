import store from '~/store'
import { config } from './config'
import Echo from 'laravel-echo'
import Pusher from 'pusher-js' // used by Echo, needs to be explicitly imported

export default () => {
  return config('broadcasting.key') && config('broadcasting.cluster') && store.state.auth.token
    ? new Echo({
        broadcaster: 'pusher',
        key: config('broadcasting.key'),
        cluster: config('broadcasting.cluster'),
        encrypted: true,
        auth: {
          headers: {
            Authorization: 'Bearer ' + store.state.auth.token
          }
        }
      })
    : null
}
