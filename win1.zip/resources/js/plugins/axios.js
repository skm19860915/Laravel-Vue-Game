import axios from 'axios'
import store from '~/store'
import router from '~/router'
import i18n from '~/plugins/i18n'

// Request interceptor
axios.interceptors.request.use(request => {
  const token = store.state.auth.token
  if (token) {
    request.headers.common['Authorization'] = `Bearer ${token}`
  }

  const locale = store.state.lang.locale
  if (locale) {
    request.headers.common['Accept-Language'] = locale
  }

  // request.headers['X-Socket-Id'] = Echo.socketId()

  return request
})

// Response interceptor
axios.interceptors.response.use(response => response, error => {
  const { status, data: { message } } = error.response

  // user is not authorized on the server, but still logged in on the client side
  if (status === 401 && store.getters['auth/check']) {
    store.dispatch('auth/logout', false)
    store.dispatch('message/error', { text: i18n.t('Your session has expired.') })
    router.push({ name: 'login' })
  // maintenance mode
  } else if (status === 503) {
    store.dispatch('message/error', { text: message })
    router.push({ name: '503' })
  // other errors (except for form validation errors)
  } else if (status !== 422 || status >= 500) {
    store.dispatch('message/error', { text: message })
  }

  return Promise.reject(error)
})
