/**
 * Format string almost like sprintf
 *
 * @returns {*}
 */
export function format () {
  var args = arguments
  return args[0].replace(/{(\d+)}/g, (match, number) => {
    var n = parseInt(number, 10)
    return typeof args[n + 1] !== 'undefined' ? args[n + 1] : match
  })
}

/**
 * Get nested object value by path
 * https://stackoverflow.com/a/43849204/2767324
 *
 * @param object
 * @param path
 * @param defaultValue
 * @returns {*}
 */
export function get (object, path, defaultValue = null) {
  return path.split('.').reduce((o, p) => o && typeof o[p] !== 'undefined' && o[p] != null ? o[p] : defaultValue, object)
}

/**
 * Set nested object value by path
 * https://stackoverflow.com/a/43849204/2767324
 *
 * @param object
 * @param path
 * @param value
 * @returns {*}
 */
export function set (object, path, value) {
  return path.split('.').reduce((o, p, i) => {
    o[p] = path.split('.').length === ++i ? value : o[p] || {}
  }, object)
}

/**
 * Copy DOM element content to clipboard
 *
 * @param el
 */
export function copyToClipboard (el) {
  el.select()
  try {
    document.execCommand('copy')
  } catch (err) {
    //
  }
  // clear selection
  document.getSelection().removeAllRanges()
  document.activeElement.blur()
}

/**
 * Check if variable is numeric
 *
 * @param n
 * @returns {boolean}
 */
export function isNumeric (n) {
  return !isNaN(parseFloat(n)) && isFinite(n)
}

/**
 * Check if variable is an integer
 *
 * @param n
 * @returns {boolean}
 */
export function isInteger (n) {
  return n === parseInt(n, 10)
}

/**
 * Capitalize first letter of a string
 *
 * @param string
 * @returns {string}
 */
export function ucfirst (string) {
  return string[0].toUpperCase() + string.slice(1)
}

/**
 * Deep merge objects or arrays
 * Source: https://stackoverflow.com/a/49798508/2767324
 *
 * @param sources
 * @returns {}
 */
export function deepMerge (...sources) {
  let acc = {}
  for (const source of sources) {
    if (source instanceof Array) {
      if (!(acc instanceof Array)) {
        acc = []
      }
      // acc = [...acc, ...source]
      acc = [...source]
    } else if (source instanceof Object) {
      for (let [key, value] of Object.entries(source)) {
        if (value instanceof Object && key in acc) {
          value = deepMerge(acc[key], value)
        }
        acc = { ...acc, [key]: value }
      }
    }
  }

  return acc
}

/**
 * Sleep for N milliseconds
 * Usage: await sleep (5000)
 *
 * @param ms
 * @returns {Promise<unknown>}
 */
export function sleep (ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

/**
 * Get website base URL
 *
 * @returns {string}
 */
export function baseUrl () {
  return window.location.origin || window.location.protocol + '//' + window.location.hostname + (window.location.port ? ':' + window.location.port : '')
}

export function lpad (string, symbol, length) {
  string = '' + string

  while (string.length < length) {
    string = symbol + string
  }

  return string
}

export function round (n, digits = 0) {
  const base = Math.pow(10, digits)
  return Math.round(n * base) / base
}

/**
 * Dynalically load an external JS script
 *
 * @param url
 * @param callback
 */
export function loadScript (url, callback) {
  var script = document.createElement('script')
  script.onload = () => {
    callback()
  }
  script.src = url
  document.body.appendChild(script)
}
