<?php

namespace App\Http\Controllers\User;

use App\Http\Requests\GetUser;
use App\Http\Requests\UpdateUser;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    public function show(Request $request)
    {
        return $request
            ->user()
            ->append('two_factor_auth_enabled', 'two_factor_auth_passed', 'is_admin')
            ->loadMissing('account', 'profiles');
    }

    /**
     * Update the user's profile information.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUser $request)
    {
        $user = $request->user();

        if ($request->hasFile('avatar') && $request->file('avatar')->isValid()) {
            // delete previous avatar if it's set
            if ($user->avatar) {
                Storage::disk('public')->delete('avatars/' . $user->avatar);
            }

            $fileName = $user->id . '_' . time() . '.' . $request->avatar->extension();
            // save uploaded logo in storage
            $request->avatar->storeAs('avatars', $fileName, 'public');
            // note that $request->merge() will not work with file uploads
            $variables = array_merge(
                $request->only('name', 'email'),
                ['avatar' => $fileName]
            );
        } else {
            $variables = $request->only('name', 'email');
        }

        return tap($user)->update($variables)->loadMissing('account');
    }

    /**
     * Public user profile
     *
     * @param GetUser $request
     * @param User $user
     * @return \Illuminate\Http\JsonResponse
     */
    public function profile(GetUser $request, User $user)
    {
        $stats = Cache::remember('user.' . $user->id . '.profile', 15*60, function () use ($user) {
            return $user
                ->account
                ->games()
                ->selectRaw('COUNT(*) AS bet_count')
                ->selectRaw('IFNULL(SUM(IF(win > bet,1,0)),0) AS win_count')
                ->selectRaw('IFNULL(SUM(bet),0) AS bet_total')
                ->selectRaw('IFNULL(SUM(win-bet),0) AS profit_total')
                ->selectRaw('IFNULL(MAX(win-bet),0) AS profit_max')
                ->get()
                ->map
                ->makeHidden(['title', 'profit', 'is_completed'])
                ->first();
        });

        return response()->json([
            'user' => $user->only('id', 'name', 'avatar_url', 'created_ago'),
            'stats' => $stats
        ]);
    }
}
