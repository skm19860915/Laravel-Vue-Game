<?php

namespace App\Http\Controllers\User;

use App\Http\Requests\ConfirmTwoFactorAuth;
use App\Http\Requests\DisableTwoFactorAuth;
use App\Http\Requests\VerifyTwoFactorAuth;
use BaconQrCode\Renderer\Image\SvgImageBackEnd;
use BaconQrCode\Renderer\ImageRenderer;
use BaconQrCode\Renderer\RendererStyle\RendererStyle;
use BaconQrCode\Writer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use PragmaRX\Google2FA\Google2FA;

class TwoFactorAuthController extends Controller
{
    public function enable(Request $request)
    {
        $user = $request->user();

        if ($user->totp_secret)
            throw ValidationException::withMessages([
                'email' => [__('Two-factor authentication is already enabled.')],
            ]);

        $google2fa = new Google2FA();
        $secret = $google2fa->generateSecretKey(32);
        $renderer = new ImageRenderer(
            new RendererStyle(250),
            new SvgImageBackEnd()
        );
        $qrCodeWriter = new Writer($renderer);
        $qrCodeSvg = $qrCodeWriter->writeString($google2fa->getQRCodeUrl(
            config('app.name'),
            $user->email,
            $secret
        ));

        return response()->json([
            'qr'        => $qrCodeSvg,
            'secret'    => $secret
        ]);
    }

    public function confirm(ConfirmTwoFactorAuth $request)
    {
        // all validations are already passed
        // get a new token with 2FA passed flag set to true
        $token = $this->refreshToken(TRUE);

        // save TOTP secret
        $user = $request->user();
        $user->totp_secret = $request->secret;
        $user->save();

        return response()->json([
            'token' => $token
        ]);
    }

    public function verify(VerifyTwoFactorAuth $request)
    {
        return response()->json([
            'token' => $this->refreshToken(TRUE)
        ]);
    }

    public function disable(DisableTwoFactorAuth $request)
    {
        // all validations are already passed
        $user = $request->user();
        $user->totp_secret = NULL;
        $user->save();

        return response()->json([
            'token' => $this->refreshToken(FALSE)
        ]);
    }

    /**
     * Refresh JWT access token
     *
     * @param $twoFactorAuthPassedClaim - should be TRUE when 2FA is being enabled or verified,
     * should be FALSE when 2FA is being disabled
     * @return mixed
     */
    private function refreshToken($twoFactorAuthPassedClaim)
    {
        $token = $twoFactorAuthPassedClaim
            ? auth()->claims(['two_factor_auth_passed' => TRUE])->refresh()
            : auth()->refresh();

        // save the token for current user
        auth()->setToken($token);

        return $token;
    }
}
