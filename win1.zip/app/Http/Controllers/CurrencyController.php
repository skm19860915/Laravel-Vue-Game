<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    public function getdata(Request $request) {

        // call api
        $url = "http://data.fixer.io/api/latest?access_key=77f13c64745be6b8180ad735876854b1";

        $cURL = curl_init();

        curl_setopt($cURL, CURLOPT_URL, $url);
        curl_setopt($cURL, CURLOPT_HTTPGET, true);

        curl_setopt($cURL, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Accept: application/json'
        ));

        $result = curl_exec($cURL);
        $result = preg_replace('/\b1$/', '', $result);
        curl_close($cURL);

        return json_decode($result);

    }
}
