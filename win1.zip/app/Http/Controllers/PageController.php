<?php

namespace App\Http\Controllers;

use App\Helpers\PackageManager;
use App\Models\Game;
use App\Services\OAuthService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;

class PageController extends Controller
{
    public function index($path = NULL, Request $request, OAuthService $OAuthService, PackageManager $packageManager)
    {
        // Get an array like this:
        // ['app' => ['name' => config('app.name'), 'locale' => config('app.locale')]]
        $mapConfigVariables = function ($key, $array) {
            return array_combine($array, array_map(function ($item) use ($key) {
                return config($key . '.' . $item);
            }, $array));
        };

        $variables = [
            'config' => [
                'app' => $mapConfigVariables('app', ['name', 'version', 'logo', 'banner', 'url', 'locale', 'default_locale', 'locales']),
                'broadcasting' => array_merge(
                    $mapConfigVariables('broadcasting.connections.pusher', ['key']),
                    $mapConfigVariables('broadcasting.connections.pusher.options', ['cluster'])
                ),
                'settings' => $mapConfigVariables('settings', ['theme', 'format', 'users', 'games', 'bonuses', 'affiliate', 'chat', 'content']),
                'services' => $OAuthService->getEnabled(['client_id', 'mdi'])
            ]
        ];

        // pass named routes
        $namedRoutes = Route::getRoutes()->getRoutesByName();

        $variables['routes'] = array_combine(
            array_keys($namedRoutes),
            array_map(function ($route) {
                return '/' . $route->uri;
            }, $namedRoutes)
        );

        // pass enabled packages (add-ons)
        $enabledPackages = $packageManager->getEnabled();

        $variables['packages'] = array_combine(
            array_keys($enabledPackages),
            array_map(function ($package) {
                return [
                    'type' => $package->type,
                    'name' => __($package->name)
                ];
            }, $enabledPackages)
        );

        // extra add-ons config
        foreach ($packageManager->getEnabled() as $package) {
            $variables['config'][$package->id] = config($package->id);
        }

        $variables['page_class'] = trim(preg_replace('#[^a-z]#i', '-', $request->path()), '-');

        return view('index', $variables);
    }

    public function show(string $page)
    {
        $file = 'html/' . preg_replace('#[^a-z0-9-_]#i', '', $page) . '.html';

        $html = Storage::disk('public')->exists($file)
            ? Storage::disk('public')->get($file)
            : (Storage::disk('assets')->exists($file)
                ? Storage::disk('assets')->get($file)
                : NULL);

        return response()->json([
            'html' => $html
        ]);
    }

    public function recentGames()
    {
        return Game::completed()
            ->orderBy('created_at', 'desc')
            ->take(10)
            // Load relations with specific columns (such as name) that can be safely shared with all users.
            ->with('account:id,user_id', 'account.user:id,name,avatar')
            ->get();
    }
}
