<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\MorphOne;

trait Gameable
{
    /**
     * Game polymorphic relationship
     *
     * @return MorphOne
     */
    public function game(): MorphOne
    {
        return $this->morphOne(Game::class, 'gameable');
    }
}
