<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Game extends Model implements PercentageAffiliateCommission
{
    const STATUS_IN_PROGRESS = 0;
    const STATUS_COMPLETED = 1;

    /**
     * The attributes that should be hidden from JSON output.
     *
     * @var array
     */
    protected $hidden = [
        'account_id',
        'gameable_id',
        'provably_fair_game_id',
        'gameable_type',
        'status'
    ];

    /**
     * This format will be used when the model is serialized to an array or JSON.
     *
     * @var array
     */
    protected $casts = [
        'bet'           => 'float',
        'bet_count'     => 'integer',
        'bet_total'     => 'float',
        'win'           => 'float',
        'win_count'     => 'integer',
        'win_total'     => 'float',
        'profit'        => 'float',
        'profit_total'  => 'float',
        'profit_max'    => 'float',
        'house_edge'    => 'float'
    ];

    protected $appends = ['is_completed', 'title', 'profit'];

    public function account()
    {
        return $this->belongsTo(Account::class);
    }

    /**
     * Scope a query to only include completed games.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeCompleted($query): Builder
    {
        return $query->where('games.status', '=', self::STATUS_COMPLETED);
    }

    public function provablyFairGame()
    {
        return $this->belongsTo(ProvablyFairGame::class);
    }

    public function gameable()
    {
        return $this->morphTo();
    }

    public function transaction()
    {
        return $this->morphOne(AccountTransaction::class, 'transactionable');
    }

    public function commission()
    {
        return $this->morphMany(AffiliateCommission::class, 'commissionable');
    }

    /**
     * Override original model's delete() method to delete (cascade) polymorphic relationships
     *
     * @return bool|null
     * @throws \Exception
     */
    public function delete()
    {
        $this->transaction()->delete(); // delete linked transaction
        $this->gameable()->delete(); // delete specific game, e.g. Dice, Roulette
        return parent::delete();
    }

    /**
     * Getter for title attribute
     *
     * @return string
     */
    public function getTitleAttribute(): string
    {
        return __(class_basename($this->gameable_type));
    }

    /**
     * Getter for profit attribute
     *
     * @return float
     */
    public function getProfitAttribute(): float
    {
        return $this->win - $this->bet;
    }

    /**
     * Getter for is_completed attribute
     *
     * @return bool
     */
    public function getIsCompletedAttribute(): bool
    {
        return $this->status == self::STATUS_COMPLETED;
    }

    public function getAffiliateCommissionBaseAmount(): float
    {
        return $this->bet;
    }
}
