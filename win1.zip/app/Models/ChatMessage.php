<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
//    protected $hidden = ['created_at', 'updated_at'];

    protected $appends = ['created_ago'];

    public function room()
    {
        return $this->belongsTo(ChatRoom::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function recipients()
    {
        return $this
            ->belongsToMany(User::class, 'chat_message_recipients', 'message_id', 'user_id')
            ->as('recipients');
    }

    public function scopeFromRoom($query, $roomId)
    {
        return $query->where('room_id', $roomId);
    }

    /**
     * Getter for created_ago attribute
     *
     * @return mixed
     */
    public function getCreatedAgoAttribute()
    {
        return $this->created_at->diffForHumans();
    }
}
